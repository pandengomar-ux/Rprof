Meilleur Prof - Static site (Final)
=====================================

Contenu:
- index.html
- styles.css
- script.js
- i18n.js (language translations FR/EN)
- images: v1.jpg, v2.jpg, ..., cours.jpg, othophoto.jpg

Instructions:
1. Dézippe l'archive.
2. Pousse les fichiers dans un repo GitHub.
3. Active GitHub Pages (Settings -> Pages -> Branch main -> root).
4. Le site devrait être en ligne quelques minutes après activation.

Le bouton EN / FR bascule toutes les sections entre le français (par défaut) et l'anglais.
